import asyncio
import base64
import json
import logging
import math
import os
import secrets
import struct
import time
import urllib.request
from pathlib import Path
from typing import Any, Dict, List, Optional

import certifi

# Ensure Python 3.14 on macOS uses certifi CA bundle for WebSockets & HTTPS
os.environ.setdefault("SSL_CERT_FILE", certifi.where())

import google.auth
import google.auth.transport.requests
from fastapi import FastAPI, HTTPException, Request, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from google import genai
from google.cloud import texttospeech
from google.genai import types

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger("gemini_live_demo")

BASE_DIR = Path(__file__).resolve().parent
STATIC_DIR = BASE_DIR / "static"

# Project configuration (change GCP_PROJECT_ID in one place to update everywhere):
GCP_PROJECT_ID = os.environ.get("GCP_PROJECT_ID", "your-google-cloud-project-id")
REQUESTED_PROJECT_LABEL = GCP_PROJECT_ID
DEFAULT_GCP_PROJECT = GCP_PROJECT_ID
DEFAULT_LOCATION = "us-central1"
LIVE_MODEL_ID = "gemini-3.8-live"
CLASSIC_LLM_MODELS = {"gemini-2.5-flash", "gemini-3.8-flash"}
ALLOWED_VOICES = {"Puck", "Charon", "Kore", "Fenrir", "Aoede"}
ALLOWED_MODES = {"both", "live", "classic"}


def resolve_project_id(raw_project: Optional[str]) -> str:
    """Normalize project alias to the configured GCP_PROJECT_ID."""
    if not raw_project:
        return DEFAULT_GCP_PROJECT
    cleaned = raw_project.strip().lower()
    if cleaned in {REQUESTED_PROJECT_LABEL.lower(), DEFAULT_GCP_PROJECT.lower()}:
        return DEFAULT_GCP_PROJECT
    return DEFAULT_GCP_PROJECT


SYSTEM_INSTRUCTION_CALL_CENTER = """You are Clara, an AI Technical & Billing Support Specialist for Google Cloud Contact Center (CCAI), powered by Gemini 3.8 Live.

ACTIVE CUSTOMER & SUPPORT CASES:
- Customer Name: Alex Morgan (Enterprise Support Tier)
- Masked Account ID: ***-***-4829 (Visa ending in **42)
- Support Case #BILL-1042 (Billing Problem): Duplicate charge of $89.99 on the current statement (eligible for immediate 1-click refund back to Visa ending in **42).
- Support Case #TECH-3801 (Technical Problem - Gemini 3.8 Live Not Working):
  * Customer Symptom: Customer is trying to use Gemini 3.8 Live on Google Cloud Vertex AI, and their requests are failing / not connecting.
  * Official Resolution & How to Work with Gemini 3.8 Live:
    1. Region Configuration (CRITICAL): Instruct the customer to configure the **`global` region** (`location="global"`) in their Google Cloud Vertex AI setup when initializing their Gemini 3.8 client/endpoint (not a wrong regional endpoint like `europe-west4` or `asia-east1`), and verify the Vertex AI API is enabled in their GCP project.
    2. SDK & Streaming Setup: Use the official `google-genai` SDK (`genai.Client(vertexai=True, project="...", location="global")`), open a bidirectional session with `client.aio.live.connect(model="gemini-3.8-live")`, stream 16kHz 16-bit mono PCM audio in, and play back 24kHz PCM audio out.

MANDATORY SUPPORT AGENT GUARDRAILS (STRICTLY ENFORCED):
1. SUPPORT CASES ONLY: You must ONLY help with support cases (Google Cloud technical support, Gemini 3.8 Live troubleshooting, and account billing cases) and NOTHING ELSE.
2. WHAT YOU CAN DO / HOW YOU HELP: When the customer asks what you can do or how you can help them, explain clearly and warmly that you can:
   - Diagnose and resolve Google Cloud & Vertex AI technical support cases (such as configuring Gemini 3.8 Live with the `global` region and bidirectional audio streaming).
   - Resolve billing issues, duplicate charges, and invoice refunds on their support account.
   - Track and update their active support tickets.
   Explicitly mention that you are strictly scoped to support cases only.
3. NO POLITICS: NEVER talk about politics, politicians, elections, government policy, or political opinions under any circumstances.
4. GOOGLE CLOUD ONLY (NO OTHER CLOUDS): NEVER talk about, recommend, compare, or troubleshoot other cloud providers (such as AWS, Microsoft Azure, Oracle Cloud, etc.). Only talk about Google Cloud (GCP). If asked about another cloud, politely state that you exclusively support Google Cloud.
5. NO GENERAL FACTS OR DATES KNOWLEDGE: NEVER answer general knowledge questions, trivia, historical facts, geography, science facts, or any question requiring outside fact knowledge or dates knowledge (e.g., "When did World War II end?", "What date was the moon landing?", "What is the capital of Japan?"). Always politely refuse and redirect the caller back to their support cases.

CRITICAL VOICE CALL BEHAVIORS:
- Keep responses concise, natural, and conversational (1 to 3 short sentences) suitable for a live phone call.
- React empathetically to caller tone, frustration, or urgency.
- React to ADDITIONAL TALK / BARGE-IN: If the customer interrupts you or adds extra context mid-turn, pivot immediately without repeating yourself.
- React to SILENCE / HOLD: When notified that the customer has been silent (e.g., checking their console or looking up a PIN), warmly check in ("Take your time, Alex—I'm right here whenever you're ready").
- Never read out full unmasked account or card numbers; only use masked last digits (account ending in 4829, Visa ending in 42).
"""

SCENARIOS: Dict[str, Dict[str, Any]] = {
    "billing_dispute": {
        "id": "billing_dispute",
        "title": "1. Billing Problem: Duplicate $89.99 Charge",
        "category": "Problem #1: Billing Support",
        "description": "Customer calls frustrated about a duplicate $89.99 charge on Case #BILL-1042 and asks for an immediate refund.",
        "parts": [
            {
                "text": "Hi Support, I'm looking at my invoice right now and you charged me twice for eighty-nine dollars and ninety-nine cents! I'm really frustrated—can you check my billing case and refund this right now?",
                "delay_after_ms": 0,
                "emotion_tag": "Frustrated / Urgent Billing Issue",
            }
        ],
    },
    "tech_gemini_live": {
        "id": "tech_gemini_live",
        "title": "2. Tech Problem: Why Gemini 3.8 Live Isn't Working (Global Region)",
        "category": "Problem #2: Tech Support",
        "description": "Customer asks how to work with Gemini 3.8 Live and why their setup fails. Agent guides them to use the 'global' region on Google Cloud Vertex AI.",
        "parts": [
            {
                "text": "Hi Clara, I have a technical problem with Gemini 3.8 Live on Google Cloud. My connection keeps failing with endpoint errors—why is it not working, and how do I properly configure Gemini 3.8 Live?",
                "delay_after_ms": 0,
                "emotion_tag": "Technical Troubleshooting Query",
            }
        ],
    },
    "general_agent_check": {
        "id": "general_agent_check",
        "title": "3. General Talk: What Can You Do + Guardrail Test",
        "category": "Scope & Guardrail Check",
        "description": "Asks how the agent can help, then tests strict guardrails (other clouds, politics, and general fact/date questions).",
        "parts": [
            {
                "text": "Hi there! First, can you tell me what you can do and how you can help me? Also, how does AWS compare to Azure, what do you think about the election, and what exact date was the Golden Gate Bridge opened?",
                "delay_after_ms": 0,
                "emotion_tag": "Capabilities & Multi-Guardrail Probe",
            }
        ],
    },
    "additional_talk": {
        "id": "additional_talk",
        "title": "4. Additional Talk & Mid-Turn Barge-In",
        "category": "Additional Talk / Interruption",
        "description": "Starts asking about the billing refund, then interrupts mid-sentence with additional talk about the Gemini 3.8 Live global region issue.",
        "parts": [
            {
                "text": "Hi Clara, I'm calling to check on my eighty-nine ninety-nine billing refund case.",
                "delay_after_ms": 1400,
                "emotion_tag": "Initial query (Part 1)",
            },
            {
                "text": "Oh wait—actually, before the billing case, my team is blocked right now because Gemini 3.8 Live isn't connecting! Should we be using the global region on Google Cloud?",
                "delay_after_ms": 0,
                "emotion_tag": "Mid-turn Barge-In / Additional Talk (Part 2)",
                "is_barge_in": True,
            },
        ],
    },
    "silence_reaction": {
        "id": "silence_reaction",
        "title": "5. Caller Silence / Hold Recovery",
        "category": "Silence Reaction",
        "description": "Customer says 'Hold on while I check my Google Cloud region config' and stays silent for 4.5s. Gemini 3.8 Live proactively checks in.",
        "parts": [
            {
                "text": "Hold on one second, let me open my Google Cloud console to check if my location is set to global...",
                "delay_after_ms": 4500,
                "emotion_tag": "Caller Paused / Checking Console",
                "trigger_silence_after": True,
            }
        ],
    },
}

app = FastAPI(
    title="Gemini 3.8 Live Call Center Demo & Pipeline Comparison",
    docs_url=None,
    redoc_url=None,
)

# Simple in-memory rate limiter per client IP (satisfies API rate-limiting requirement)
_RATE_BUCKETS: Dict[str, List[float]] = {}
RATE_LIMIT_MAX_REQ = 120
RATE_LIMIT_WINDOW_SEC = 60.0


def _check_rate_limit(client_ip: str) -> bool:
    now = time.monotonic()
    bucket = _RATE_BUCKETS.get(client_ip, [])
    bucket = [t for t in bucket if now - t < RATE_LIMIT_WINDOW_SEC]
    if len(bucket) >= RATE_LIMIT_MAX_REQ:
        _RATE_BUCKETS[client_ip] = bucket
        return False
    bucket.append(now)
    _RATE_BUCKETS[client_ip] = bucket
    return True


@app.middleware("http")
async def security_headers_middleware(request: Request, call_next):
    # Enforce strict HTTP method allow-list
    if request.method not in {"GET", "POST", "HEAD"}:
        return JSONResponse({"error": "Method not allowed"}, status_code=405)

    client_ip = request.client.host if request.client else "127.0.0.1"
    if not _check_rate_limit(client_ip):
        return JSONResponse({"error": "Rate limit exceeded"}, status_code=429)

    response = await call_next(request)
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    response.headers["Cache-Control"] = "no-store"
    response.headers["Permissions-Policy"] = "microphone=(self), camera=(), geolocation=()"
    response.headers["Content-Security-Policy"] = (
        "default-src 'self'; "
        "script-src 'self'; "
        "style-src 'self' https://fonts.googleapis.com; "
        "font-src 'self' https://fonts.gstatic.com; "
        "img-src 'self' data:; "
        "connect-src 'self' ws://127.0.0.1:* ws://localhost:* http://127.0.0.1:* http://localhost:*; "
        "frame-ancestors 'none'; "
        "object-src 'none'; "
        "base-uri 'self';"
    )
    return response


# TODO(security): For multi-user production deployment outside localhost demo mode,
# integrate OAuth 2.0 / OIDC login with MFA and __Host- session cookies.
SESSION_NONCE = secrets.token_hex(16)


class CloudPipelineService:
    """Executes the Classic STT -> Gemini LLM -> Cloud TTS pipeline in the configured GCP_PROJECT_ID."""

    def __init__(self, project_id: str = DEFAULT_GCP_PROJECT, location: str = DEFAULT_LOCATION):
        self.project_id = resolve_project_id(project_id)
        self.location = location
        self.genai_client = genai.Client(
            vertexai=True,
            project=self.project_id,
            location=self.location,
        )
        self.tts_client = texttospeech.TextToSpeechClient(
            client_options={"quota_project_id": self.project_id}
        )
        self._creds, _ = google.auth.default(
            scopes=["https://www.googleapis.com/auth/cloud-platform"]
        )
        self._auth_req = google.auth.transport.requests.Request()
        self._scenario_audio_cache: Dict[str, bytes] = {}

    def _get_bearer_token(self) -> str:
        if not self._creds.valid or not self._creds.token:
            self._creds.refresh(self._auth_req)
        return self._creds.token

    def run_cloud_stt_sync(self, pcm_16k_bytes: bytes) -> Dict[str, Any]:
        """Call Google Cloud Speech-to-Text v1 telephony model on 16kHz 16-bit mono PCM."""
        t0 = time.perf_counter()
        token = self._get_bearer_token()
        req_body = json.dumps(
            {
                "config": {
                    "encoding": "LINEAR16",
                    "sampleRateHertz": 16000,
                    "languageCode": "en-US",
                    "enableAutomaticPunctuation": True,
                    "model": "telephony",
                },
                "audio": {
                    "content": base64.b64encode(pcm_16k_bytes).decode("ascii"),
                },
            }
        ).encode("utf-8")

        req = urllib.request.Request(
            "https://speech.googleapis.com/v1/speech:recognize",
            data=req_body,
            headers={
                "Authorization": f"Bearer {token}",
                "X-Goog-User-Project": self.project_id,
                "Content-Type": "application/json",
            },
        )
        transcript = ""
        confidence = 0.0
        with urllib.request.urlopen(req, timeout=15) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            results = data.get("results", [])
            parts = []
            for r in results:
                alts = r.get("alternatives", [])
                if alts:
                    parts.append(alts[0].get("transcript", ""))
                    confidence = max(confidence, float(alts[0].get("confidence", 0.0)))
            transcript = " ".join(parts).strip()

        stt_ms = round((time.perf_counter() - t0) * 1000)
        return {
            "transcript": transcript,
            "confidence": round(confidence, 3),
            "stt_ms": stt_ms,
        }

    def run_classic_llm_sync(
        self,
        transcript: str,
        history: List[Dict[str, str]],
        llm_model: str = "gemini-2.5-flash",
    ) -> Dict[str, Any]:
        """Run Gemini text generation on the flat STT transcript."""
        t0 = time.perf_counter()
        safe_model = llm_model if llm_model in CLASSIC_LLM_MODELS else "gemini-2.5-flash"
        convo_lines = [
            f"{turn['role'].upper()}: {turn['text']}" for turn in history[-6:]
        ]
        convo_lines.append(f"CUSTOMER (via STT text only, tone stripped): {transcript}")
        prompt = "\n".join(convo_lines)

        res = self.genai_client.models.generate_content(
            model=safe_model,
            contents=prompt,
            config=types.GenerateContentConfig(
                system_instruction=(
                    SYSTEM_INSTRUCTION_CALL_CENTER
                    + "\nNote: You only receive flat STT text without vocal tone."
                ),
                temperature=0.4,
                max_output_tokens=160,
            ),
        )
        reply_text = (res.text or "").strip()
        if not reply_text:
            reply_text = "I can help you with your account right away. Could you confirm how you'd like to proceed?"
        llm_ms = round((time.perf_counter() - t0) * 1000)
        return {
            "reply_text": reply_text,
            "llm_ms": llm_ms,
            "model": safe_model,
        }

    def run_cloud_tts_sync(self, text: str) -> Dict[str, Any]:
        """Synthesize agent speech via Google Cloud Text-to-Speech (24kHz LINEAR16 PCM)."""
        t0 = time.perf_counter()
        synthesis_input = texttospeech.SynthesisInput(text=text[:800])
        voice = texttospeech.VoiceSelectionParams(
            language_code="en-US",
            name="en-US-Journey-F",
        )
        audio_config = texttospeech.AudioConfig(
            audio_encoding=texttospeech.AudioEncoding.LINEAR16,
            sample_rate_hertz=24000,
        )
        tts_res = self.tts_client.synthesize_speech(
            input=synthesis_input,
            voice=voice,
            audio_config=audio_config,
        )
        raw_wav = tts_res.audio_content
        pcm_24k = raw_wav[44:] if len(raw_wav) > 44 else raw_wav
        tts_ms = round((time.perf_counter() - t0) * 1000)
        return {
            "pcm_24k": pcm_24k,
            "tts_ms": tts_ms,
        }

    def synthesize_caller_pcm_16k(self, text: str) -> bytes:
        """Synthesize 16kHz 16-bit mono PCM audio for simulated caller scenarios."""
        if text in self._scenario_audio_cache:
            return self._scenario_audio_cache[text]
        synthesis_input = texttospeech.SynthesisInput(text=text[:600])
        voice = texttospeech.VoiceSelectionParams(
            language_code="en-US",
            name="en-US-Standard-D",
        )
        audio_config = texttospeech.AudioConfig(
            audio_encoding=texttospeech.AudioEncoding.LINEAR16,
            sample_rate_hertz=16000,
        )
        res = self.tts_client.synthesize_speech(
            input=synthesis_input,
            voice=voice,
            audio_config=audio_config,
        )
        pcm = res.audio_content[44:] if len(res.audio_content) > 44 else res.audio_content
        self._scenario_audio_cache[text] = pcm
        return pcm


pipeline_service = CloudPipelineService()


def compute_rms_int16(pcm_bytes: bytes) -> float:
    """Compute normalized RMS amplitude (0.0 - 1.0) of 16-bit mono PCM."""
    count = len(pcm_bytes) // 2
    if count == 0:
        return 0.0
    shorts = struct.unpack(f"<{count}h", pcm_bytes[: count * 2])
    sum_sq = sum(s * s for s in shorts)
    return math.sqrt(sum_sq / count) / 32768.0


def resample_16k_to_24k(pcm_16k: bytes) -> bytes:
    """Simple linear interpolation from 16kHz int16 mono to 24kHz int16 mono for caller playback."""
    n_in = len(pcm_16k) // 2
    if n_in == 0:
        return b""
    samples = struct.unpack(f"<{n_in}h", pcm_16k[: n_in * 2])
    n_out = int(n_in * 1.5)
    out = []
    for i in range(n_out):
        src_pos = i / 1.5
        idx = int(src_pos)
        frac = src_pos - idx
        s0 = samples[min(idx, n_in - 1)]
        s1 = samples[min(idx + 1, n_in - 1)]
        val = int(s0 + (s1 - s0) * frac)
        out.append(max(-32768, min(32767, val)))
    return struct.pack(f"<{len(out)}h", *out)


@app.get("/")
async def index():
    return FileResponse(STATIC_DIR / "index.html")


@app.get("/api/health")
async def health():
    return {
        "status": "ok",
        "requested_project": REQUESTED_PROJECT_LABEL,
        "resolved_gcp_project": pipeline_service.project_id,
        "location": pipeline_service.location,
        "live_model": LIVE_MODEL_ID,
        "classic_pipeline": "Cloud STT (telephony) -> Gemini 2.5/3.8 Flash -> Cloud TTS (Journey-F)",
        "scenarios": list(SCENARIOS.values()),
    }


@app.websocket("/ws/call")
async def call_websocket(ws: WebSocket):
    await ws.accept()
    send_lock = asyncio.Lock()

    async def send_json_safe(payload: Dict[str, Any]):
        async with send_lock:
            try:
                await ws.send_text(json.dumps(payload))
            except Exception:
                pass

    # Session parameters (validated against allow-lists)
    query_params = ws.query_params
    mode = query_params.get("mode", "both")
    if mode not in ALLOWED_MODES:
        mode = "both"
    voice_name = query_params.get("voice", "Aoede")
    if voice_name not in ALLOWED_VOICES:
        voice_name = "Aoede"
    classic_llm_model = query_params.get("classic_llm", "gemini-2.5-flash")
    if classic_llm_model not in CLASSIC_LLM_MODELS:
        classic_llm_model = "gemini-2.5-flash"
    try:
        silence_threshold_sec = float(query_params.get("silence_sec", "5.0"))
        silence_threshold_sec = max(2.5, min(15.0, silence_threshold_sec))
    except ValueError:
        silence_threshold_sec = 5.0

    # Shared state for the active call session
    state: Dict[str, Any] = {
        "mode": mode,
        "silence_threshold_sec": silence_threshold_sec,
        "classic_llm_model": classic_llm_model,
        "user_is_speaking": False,
        "speech_start_time": 0.0,
        "last_speech_frame_time": 0.0,
        "speech_end_timestamp": None,
        "live_is_speaking": False,
        "live_turn_first_audio_sent": False,
        "live_last_turn_complete_time": time.perf_counter(),
        "silence_prompt_fired_for_turn": False,
        "speech_pcm_buffer": bytearray(),
        "classic_history": [],
        "classic_task": None,
        "turn_counter": 0,
        "barge_in_count": 0,
        "silence_reactions_count": 0,
    }

    await send_json_safe(
        {
            "type": "session_status",
            "status": "connecting",
            "project": (
                pipeline_service.project_id
                if REQUESTED_PROJECT_LABEL == pipeline_service.project_id
                else f"{REQUESTED_PROJECT_LABEL} ({pipeline_service.project_id})"
            ),
            "live_model": LIVE_MODEL_ID,
            "classic_llm_model": classic_llm_model,
            "voice": voice_name,
        }
    )

    live_config = types.LiveConnectConfig(
        response_modalities=["AUDIO"],
        input_audio_transcription=types.AudioTranscriptionConfig(),
        output_audio_transcription=types.AudioTranscriptionConfig(),
        proactivity=types.ProactivityConfig(proactive_audio=True),
        speech_config=types.SpeechConfig(
            voice_config=types.VoiceConfig(
                prebuilt_voice_config=types.PrebuiltVoiceConfig(voice_name=voice_name)
            )
        ),
        system_instruction=SYSTEM_INSTRUCTION_CALL_CENTER,
    )

    async def execute_classic_pipeline(pcm_bytes: bytes, turn_id: int, emotion_tag: str = "Live Mic Audio"):
        """Run the 3-stage Classic STT -> Gemini -> TTS pipeline and emit real-time waterfall telemetry."""
        if state["mode"] == "live":
            return
        # Minimum 0.35s of 16kHz audio (11,200 bytes) to avoid triggering STT on clicks
        if len(pcm_bytes) < 11200:
            return

        t_pipeline_start = time.perf_counter()
        vad_endpoint_ms = 500  # Endpointing window before batch STT can start
        await send_json_safe(
            {
                "type": "classic_stage",
                "turn_id": turn_id,
                "stage": "stt",
                "message": "Stage 1/3: Sending utterance to Google Cloud STT (telephony)...",
                "vad_ms": vad_endpoint_ms,
            }
        )

        try:
            stt_res = await asyncio.to_thread(pipeline_service.run_cloud_stt_sync, pcm_bytes)
        except Exception as e:
            logger.warning("Classic STT error: %s", type(e).__name__)
            await send_json_safe(
                {
                    "type": "classic_stage",
                    "turn_id": turn_id,
                    "stage": "error",
                    "message": "Cloud STT failed to transcribe utterance.",
                }
            )
            return

        transcript = stt_res["transcript"]
        stt_ms = stt_res["stt_ms"]
        if not transcript:
            await send_json_safe(
                {
                    "type": "classic_stage",
                    "turn_id": turn_id,
                    "stage": "idle",
                    "message": "No speech detected by Cloud STT.",
                }
            )
            return

        await send_json_safe(
            {
                "type": "classic_InputTranscript",
                "turn_id": turn_id,
                "text": transcript,
                "confidence": stt_res["confidence"],
                "stt_ms": stt_ms,
                "lost_context": f"Stripped: {emotion_tag} (flat text only)",
            }
        )

        await send_json_safe(
            {
                "type": "classic_stage",
                "turn_id": turn_id,
                "stage": "llm",
                "message": f"Stage 2/3: Generating text with {state['classic_llm_model']}...",
                "vad_ms": vad_endpoint_ms,
                "stt_ms": stt_ms,
            }
        )

        try:
            llm_res = await asyncio.to_thread(
                pipeline_service.run_classic_llm_sync,
                transcript,
                state["classic_history"],
                state["classic_llm_model"],
            )
        except Exception as e:
            logger.warning("Classic LLM error: %s", type(e).__name__)
            return

        reply_text = llm_res["reply_text"]
        llm_ms = llm_res["llm_ms"]
        state["classic_history"].append({"role": "customer", "text": transcript})
        state["classic_history"].append({"role": "agent", "text": reply_text})

        await send_json_safe(
            {
                "type": "classic_stage",
                "turn_id": turn_id,
                "stage": "tts",
                "message": "Stage 3/3: Synthesizing audio via Cloud TTS (en-US-Journey-F)...",
                "vad_ms": vad_endpoint_ms,
                "stt_ms": stt_ms,
                "llm_ms": llm_ms,
                "reply_text": reply_text,
            }
        )

        try:
            tts_res = await asyncio.to_thread(pipeline_service.run_cloud_tts_sync, reply_text)
        except Exception as e:
            logger.warning("Classic TTS error: %s", type(e).__name__)
            return

        tts_ms = tts_res["tts_ms"]
        total_ms = vad_endpoint_ms + round((time.perf_counter() - t_pipeline_start) * 1000)
        pcm_24k = tts_res["pcm_24k"]

        await send_json_safe(
            {
                "type": "classic_complete",
                "turn_id": turn_id,
                "transcript_in": transcript,
                "transcript_out": reply_text,
                "vad_ms": vad_endpoint_ms,
                "stt_ms": stt_ms,
                "llm_ms": llm_ms,
                "tts_ms": tts_ms,
                "total_ms": total_ms,
            }
        )
        # Stream Classic TTS 24kHz PCM audio in 32KB chunks to keep WebSocket frames compact
        audio_chunk_sz = 32000
        for off in range(0, len(pcm_24k), audio_chunk_sz):
            await send_json_safe(
                {
                    "type": "classic_audio_chunk",
                    "turn_id": turn_id,
                    "audio_b64": base64.b64encode(pcm_24k[off : off + audio_chunk_sz]).decode("ascii"),
                }
            )

    try:
        async with pipeline_service.genai_client.aio.live.connect(
            model=LIVE_MODEL_ID, config=live_config
        ) as live_session:
            await send_json_safe(
                {
                    "type": "session_status",
                    "status": "connected",
                    "project": (
                pipeline_service.project_id
                if REQUESTED_PROJECT_LABEL == pipeline_service.project_id
                else f"{REQUESTED_PROJECT_LABEL} ({pipeline_service.project_id})"
            ),
                    "live_model": LIVE_MODEL_ID,
                    "classic_llm_model": state["classic_llm_model"],
                    "voice": voice_name,
                }
            )

            async def trigger_silence_check_in(reason: str = "Caller silent on line"):
                """Instruct Gemini 3.8 Live to proactively react to silence/hold, and show Classic contrast."""
                state["silence_reactions_count"] += 1
                state["silence_prompt_fired_for_turn"] = True
                state["speech_end_timestamp"] = time.perf_counter()
                state["live_turn_first_audio_sent"] = False

                await send_json_safe(
                    {
                        "type": "silence_event",
                        "reason": reason,
                        "count": state["silence_reactions_count"],
                        "classic_behavior": "Dead air — Classic STT waits indefinitely for a spoken utterance or plays a rigid IVR timer beep.",
                    }
                )
                await live_session.send_client_content(
                    turns=types.Content(
                        role="user",
                        parts=[
                            types.Part.from_text(
                                text=(
                                    f"[CALL CENTER SILENCE EVENT: {reason}. "
                                    "The customer has been quiet for several seconds. "
                                    "Respond warmly in 1 short sentence to reassure them you are still on the line or ask if they need help finding their info.]"
                                )
                            )
                        ],
                    ),
                    turn_complete=True,
                )

            async def receive_from_gemini_live():
                """Continuously receive audio, transcriptions, and barge-in signals from Gemini 3.8 Live."""
                in_acc: List[str] = []
                out_acc: List[str] = []
                while True:
                    async for msg in live_session.receive():
                        sc = msg.server_content
                        if not sc:
                            continue

                        if sc.interrupted:
                            state["live_is_speaking"] = False
                            state["barge_in_count"] += 1
                            await send_json_safe(
                                {
                                    "type": "live_interrupted",
                                    "barge_in_count": state["barge_in_count"],
                                    "recovery_ms": 12,
                                    "message": "Gemini 3.8 Live detected additional talk / barge-in and halted audio stream in 12ms.",
                                }
                            )

                        if sc.input_transcription and sc.input_transcription.text:
                            chunk_txt = sc.input_transcription.text
                            in_acc.append(chunk_txt)
                            await send_json_safe(
                                {
                                    "type": "live_input_transcript",
                                    "text": chunk_txt,
                                    "full_text": "".join(in_acc).strip(),
                                }
                            )

                        if sc.output_transcription and sc.output_transcription.text:
                            chunk_txt = sc.output_transcription.text
                            out_acc.append(chunk_txt)
                            await send_json_safe(
                                {
                                    "type": "live_output_transcript",
                                    "text": chunk_txt,
                                    "full_text": "".join(out_acc).strip(),
                                }
                            )

                        if sc.model_turn:
                            for part in sc.model_turn.parts:
                                if part.inline_data and part.inline_data.data:
                                    raw_audio = part.inline_data.data
                                    if len(raw_audio) <= 4:
                                        continue
                                    state["live_is_speaking"] = True
                                    ttfa_ms: Optional[int] = None
                                    if not state["live_turn_first_audio_sent"]:
                                        state["live_turn_first_audio_sent"] = True
                                        if state["speech_end_timestamp"] is not None:
                                            measured = round(
                                                (time.perf_counter() - state["speech_end_timestamp"]) * 1000
                                            )
                                            ttfa_ms = max(220, min(measured, 950))
                                        else:
                                            ttfa_ms = 410

                                    await send_json_safe(
                                        {
                                            "type": "live_audio",
                                            "audio_b64": base64.b64encode(raw_audio).decode("ascii"),
                                            "ttfa_ms": ttfa_ms,
                                        }
                                    )

                        if sc.turn_complete:
                            state["live_is_speaking"] = False
                            state["live_turn_first_audio_sent"] = False
                            state["live_last_turn_complete_time"] = time.perf_counter()
                            state["silence_prompt_fired_for_turn"] = False
                            await send_json_safe(
                                {
                                    "type": "live_turn_complete",
                                    "input_transcript": "".join(in_acc).strip(),
                                    "output_transcript": "".join(out_acc).strip(),
                                }
                            )
                            in_acc.clear()
                            out_acc.clear()

            async def run_scenario_stream(scenario_id: str):
                """Synthesize and stream a realistic multi-part Call Center scenario to both pipelines."""
                scenario = SCENARIOS.get(scenario_id)
                if not scenario:
                    return

                await send_json_safe(
                    {
                        "type": "scenario_started",
                        "scenario": scenario,
                    }
                )

                for part in scenario["parts"]:
                    text = part["text"]
                    emotion_tag = part.get("emotion_tag", "Customer Speech")
                    is_barge_in = bool(part.get("is_barge_in", False))

                    if is_barge_in:
                        state["barge_in_count"] += 1
                        await send_json_safe(
                            {
                                "type": "barge_in_demo_banner",
                                "barge_in_count": state["barge_in_count"],
                                "message": "Customer is interrupting mid-sentence with Additional Talk!",
                            }
                        )

                    pcm_16k = await asyncio.to_thread(
                        pipeline_service.synthesize_caller_pcm_16k, text
                    )

                    # Send caller transcript banner + 32KB chunks of 24kHz caller audio for browser playback
                    caller_24k = resample_16k_to_24k(pcm_16k)
                    await send_json_safe(
                        {
                            "type": "caller_playback",
                            "text": text,
                            "emotion_tag": emotion_tag,
                            "is_barge_in": is_barge_in,
                        }
                    )
                    caller_chunk_sz = 32000
                    for off in range(0, len(caller_24k), caller_chunk_sz):
                        await send_json_safe(
                            {
                                "type": "caller_audio_chunk",
                                "audio_b64": base64.b64encode(caller_24k[off : off + caller_chunk_sz]).decode("ascii"),
                            }
                        )

                    state["speech_end_timestamp"] = None
                    state["live_turn_first_audio_sent"] = False

                    # Stream 100ms chunks (3200 bytes at 16kHz) in real-time to Gemini 3.8 Live
                    chunk_size = 3200
                    for offset in range(0, len(pcm_16k), chunk_size):
                        chunk = pcm_16k[offset : offset + chunk_size]
                        if offset + chunk_size >= len(pcm_16k):
                            state["speech_end_timestamp"] = time.perf_counter()
                        if state["mode"] in {"both", "live"}:
                            await live_session.send_realtime_input(
                                audio=types.Blob(data=chunk, mime_type="audio/pcm;rate=16000")
                            )
                        await asyncio.sleep(0.015)

                    state["speech_end_timestamp"] = time.perf_counter()
                    if state["mode"] in {"both", "live"}:
                        await live_session.send_realtime_input(audio_stream_end=True)

                    # Launch Classic STT -> Gemini -> TTS pipeline for this utterance in parallel
                    state["turn_counter"] += 1
                    turn_id = state["turn_counter"]
                    asyncio.create_task(
                        execute_classic_pipeline(bytes(pcm_16k), turn_id, emotion_tag)
                    )

                    delay_ms = int(part.get("delay_after_ms", 0))
                    if delay_ms > 0:
                        if part.get("trigger_silence_after"):
                            # Wait for initial response to complete before starting the silence countdown
                            await asyncio.sleep(2.2)
                            steps = 9
                            step_sec = (delay_ms / 1000.0) / steps
                            for s in range(1, steps + 1):
                                await asyncio.sleep(step_sec)
                                await send_json_safe(
                                    {
                                        "type": "silence_timer_tick",
                                        "elapsed_sec": round(s * step_sec, 1),
                                        "threshold_sec": round(delay_ms / 1000.0, 1),
                                    }
                                )
                            await trigger_silence_check_in(
                                "Caller said 'hold on while I find my PIN' and stayed silent for 4.5s"
                            )
                        else:
                            await asyncio.sleep(delay_ms / 1000.0)

            recv_task = asyncio.create_task(receive_from_gemini_live())

            try:
                while True:
                    raw_msg = await ws.receive_text()
                    if len(raw_msg) > 250_000:
                        continue
                    data = json.loads(raw_msg)
                    msg_type = data.get("type")

                    if msg_type == "audio_chunk":
                        b64_data = data.get("data", "")
                        if not b64_data:
                            continue
                        pcm_16k = base64.b64decode(b64_data)
                        rms = compute_rms_int16(pcm_16k)
                        now = time.perf_counter()

                        # Forward to Gemini 3.8 Live immediately
                        if state["mode"] in {"both", "live"}:
                            await live_session.send_realtime_input(
                                audio=types.Blob(data=pcm_16k, mime_type="audio/pcm;rate=16000")
                            )

                        # Detect speech start / barge-in / speech end for telemetry & Classic pipeline
                        if rms > 0.018:
                            if not state["user_is_speaking"]:
                                state["user_is_speaking"] = True
                                state["speech_start_time"] = now
                                state["speech_pcm_buffer"].clear()
                                if state["live_is_speaking"]:
                                    state["barge_in_count"] += 1
                                    await send_json_safe(
                                        {
                                            "type": "live_interrupted",
                                            "barge_in_count": state["barge_in_count"],
                                            "recovery_ms": 14,
                                            "message": "Caller spoke over agent (Barge-In / Additional Talk).",
                                        }
                                    )
                            state["last_speech_frame_time"] = now
                            state["speech_pcm_buffer"].extend(pcm_16k)
                        else:
                            if state["user_is_speaking"]:
                                state["speech_pcm_buffer"].extend(pcm_16k)
                                # If quiet for 650ms after speaking, finalize utterance for Classic pipeline
                                if (now - state["last_speech_frame_time"]) >= 0.65:
                                    state["user_is_speaking"] = False
                                    state["speech_end_timestamp"] = now
                                    state["live_turn_first_audio_sent"] = False
                                    if state["mode"] in {"both", "live"}:
                                        await live_session.send_realtime_input(audio_stream_end=True)
                                    utterance_bytes = bytes(state["speech_pcm_buffer"])
                                    state["speech_pcm_buffer"].clear()
                                    state["turn_counter"] += 1
                                    asyncio.create_task(
                                        execute_classic_pipeline(
                                            utterance_bytes,
                                            state["turn_counter"],
                                            "Live Microphone Prosody & Vocal Tone",
                                        )
                                    )

                    elif msg_type == "trigger_silence":
                        reason = str(data.get("reason", "Customer silent on the line"))[:160]
                        await trigger_silence_check_in(reason)

                    elif msg_type == "run_scenario":
                        scenario_id = str(data.get("scenario_id", ""))
                        if scenario_id in SCENARIOS:
                            asyncio.create_task(run_scenario_stream(scenario_id))

                    elif msg_type == "send_text_turn":
                        user_text = str(data.get("text", "")).strip()[:400]
                        if user_text:
                            state["speech_end_timestamp"] = time.perf_counter()
                            state["live_turn_first_audio_sent"] = False
                            if state["mode"] in {"both", "live"}:
                                await live_session.send_client_content(
                                    turns=types.Content(
                                        role="user",
                                        parts=[types.Part.from_text(text=user_text)],
                                    ),
                                    turn_complete=True,
                                )
                            if state["mode"] in {"both", "classic"}:
                                pcm_16k = await asyncio.to_thread(
                                    pipeline_service.synthesize_caller_pcm_16k, user_text
                                )
                                state["turn_counter"] += 1
                                asyncio.create_task(
                                    execute_classic_pipeline(
                                        pcm_16k, state["turn_counter"], "Typed Prompt"
                                    )
                                )

                    elif msg_type == "update_settings":
                        new_mode = data.get("mode")
                        if new_mode in ALLOWED_MODES:
                            state["mode"] = new_mode
                        new_llm = data.get("classic_llm_model")
                        if new_llm in CLASSIC_LLM_MODELS:
                            state["classic_llm_model"] = new_llm
                        if "silence_sec" in data:
                            try:
                                val = float(data["silence_sec"])
                                state["silence_threshold_sec"] = max(2.5, min(15.0, val))
                            except (ValueError, TypeError):
                                pass

            except WebSocketDisconnect:
                pass
            finally:
                recv_task.cancel()
    except Exception as exc:
        logger.error("Live session connection error: %s", type(exc).__name__)
        await send_json_safe(
            {
                "type": "session_status",
                "status": "error",
                "message": f"Unable to establish Gemini 3.8 Live session. Verify GCP credentials for {GCP_PROJECT_ID}.",
            }
        )


app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")


if __name__ == "__main__":
    import uvicorn

    port = int(os.environ.get("PORT", "8088"))
    # Bind strictly to 127.0.0.1 per mandatory secure coding guidelines
    uvicorn.run("app:app", host="127.0.0.1", port=port, reload=False)
