(() => {
  "use strict";

  // DOM References
  const connectBtn = document.getElementById("connectBtn");
  const connectBtnLabel = document.getElementById("connectBtnLabel");
  const micBtn = document.getElementById("micBtn");
  const micBtnLabel = document.getElementById("micBtnLabel");
  const silenceBtn = document.getElementById("silenceBtn");
  const modeSelect = document.getElementById("modeSelect");
  const audioOutputSelect = document.getElementById("audioOutputSelect");
  const silenceThresholdSelect = document.getElementById("silenceThresholdSelect");
  const connectionPill = document.getElementById("connectionPill");
  const connectionText = document.getElementById("connectionText");
  const projectBadge = document.getElementById("projectBadge");

  const micStateLabel = document.getElementById("micStateLabel");
  const waveformCanvas = document.getElementById("waveformCanvas");
  const silenceTimerText = document.getElementById("silenceTimerText");
  const silenceProgressFill = document.getElementById("silenceProgressFill");

  const quickTextInput = document.getElementById("quickTextInput");
  const sendTextBtn = document.getElementById("sendTextBtn");
  const clearHistoryBtn = document.getElementById("clearHistoryBtn");

  // Waterfall & Metrics DOM
  const speedupBadge = document.getElementById("speedupBadge");
  const wfLiveLabel = document.getElementById("wfLiveLabel");
  const wfClassicLabel = document.getElementById("wfClassicLabel");
  const wfBarLive = document.getElementById("wfBarLive");
  const wfSegVad = document.getElementById("wfSegVad");
  const wfSegStt = document.getElementById("wfSegStt");
  const wfSegLlm = document.getElementById("wfSegLlm");
  const wfSegTts = document.getElementById("wfSegTts");

  const liveStateBadge = document.getElementById("liveStateBadge");
  const classicStateBadge = document.getElementById("classicStateBadge");
  const liveLastTtfa = document.getElementById("liveLastTtfa");
  const liveAvgTtfa = document.getElementById("liveAvgTtfa");
  const liveBargeMs = document.getElementById("liveBargeMs");
  const liveEventsCount = document.getElementById("liveEventsCount");

  const stepStt = document.getElementById("stepStt");
  const stepLlm = document.getElementById("stepLlm");
  const stepTts = document.getElementById("stepTts");
  const stepSttTime = document.getElementById("stepSttTime");
  const stepLlmTime = document.getElementById("stepLlmTime");
  const stepTtsTime = document.getElementById("stepTtsTime");
  const classicLastTtfa = document.getElementById("classicLastTtfa");

  const liveTranscriptBox = document.getElementById("liveTranscriptBox");
  const classicTranscriptBox = document.getElementById("classicTranscriptBox");

  const tableLiveTtfa = document.getElementById("tableLiveTtfa");
  const tableClassicTtfa = document.getElementById("tableClassicTtfa");
  const tableLatencyDelta = document.getElementById("tableLatencyDelta");
  const tableBargeImpact = document.getElementById("tableBargeImpact");
  const tableSilenceImpact = document.getElementById("tableSilenceImpact");

  // Runtime State
  let ws = null;
  let isConnected = false;
  let pendingScenarioAfterConnect = null;

  // Audio Playback Context (24kHz)
  let playbackCtx = null;
  let nextPlayTime = 0;
  let activeAudioSources = [];
  let deferredClassicAudioQueue = [];

  // Microphone Capture State (16kHz)
  let micStream = null;
  let micAudioCtx = null;
  let micProcessor = null;
  let isMicActive = false;
  let currentRms = 0;

  // Silence Monitor State
  let lastActivityTimestamp = performance.now();
  let agentFinishedTurn = false;
  let silenceTriggeredThisTurn = false;

  // Telemetry Accumulators
  const liveTtfaHistory = [];
  const classicTtfaHistory = [];
  let lastMeasuredLiveMs = null;
  let lastMeasuredClassicMs = null;
  let silenceCount = 0;
  let bargeInCount = 0;

  // Active Streaming Bubbles in Gemini 3.8 Live Panel
  let activeLiveInputBubbleText = null;
  let activeLiveOutputBubbleText = null;
  let activeLiveOutputBadge = null;

  function ensurePlaybackContext() {
    if (!playbackCtx) {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      playbackCtx = new AudioCtx({ sampleRate: 24000 });
    }
    if (playbackCtx.state === "suspended") {
      playbackCtx.resume();
    }
  }

  function stopAllPlaybackImmediately() {
    for (const src of activeAudioSources) {
      try {
        src.stop(0);
        src.disconnect();
      } catch (_e) {
        // Ignore already stopped sources
      }
    }
    activeAudioSources = [];
    if (playbackCtx) {
      nextPlayTime = playbackCtx.currentTime;
    }
  }

  function enqueuePcm24kBase64(b64Data, gainValue = 1.0) {
    if (!b64Data) return;
    ensurePlaybackContext();

    const binaryStr = window.atob(b64Data);
    const byteLen = binaryStr.length;
    const sampleCount = Math.floor(byteLen / 2);
    if (sampleCount <= 0) return;

    const float32 = new Float32Array(sampleCount);
    for (let i = 0; i < sampleCount; i++) {
      const lo = binaryStr.charCodeAt(i * 2);
      const hi = binaryStr.charCodeAt(i * 2 + 1);
      let int16 = (hi << 8) | lo;
      if (int16 >= 0x8000) int16 -= 0x10000;
      float32[i] = (int16 / 32768.0) * gainValue;
    }

    const audioBuffer = playbackCtx.createBuffer(1, sampleCount, 24000);
    audioBuffer.getChannelData(0).set(float32);

    const source = playbackCtx.createBufferSource();
    source.buffer = audioBuffer;
    source.connect(playbackCtx.destination);

    const now = playbackCtx.currentTime;
    if (nextPlayTime < now) {
      nextPlayTime = now + 0.015;
    }
    source.start(nextPlayTime);
    nextPlayTime += audioBuffer.duration;

    activeAudioSources.push(source);
    source.onended = () => {
      activeAudioSources = activeAudioSources.filter((s) => s !== source);
    };
  }

  // Safe DOM Builder Helpers (No innerHTML used anywhere)
  function clearEmptyPlaceholder(container) {
    const empty = container.querySelector(".empty-state");
    if (empty) {
      empty.remove();
    }
  }

  function appendChatBubble(container, roleClass, titleText, badgeText, bodyText) {
    clearEmptyPlaceholder(container);
    const bubble = document.createElement("div");
    bubble.className = `chat-bubble ${roleClass}`;

    const meta = document.createElement("div");
    meta.className = "bubble-meta";

    const roleSpan = document.createElement("span");
    roleSpan.textContent = titleText;
    meta.appendChild(roleSpan);

    const badgeSpan = document.createElement("span");
    badgeSpan.className = "bubble-badge";
    badgeSpan.textContent = badgeText || "";
    meta.appendChild(badgeSpan);

    const contentDiv = document.createElement("div");
    contentDiv.textContent = bodyText;

    bubble.appendChild(meta);
    bubble.appendChild(contentDiv);
    container.appendChild(bubble);
    container.scrollTop = container.scrollHeight;

    return { bubble, badgeSpan, contentDiv };
  }

  function updateConnectionUI(state, label) {
    connectionPill.setAttribute("data-state", state);
    connectionText.textContent = label;
    if (state === "connected") {
      connectBtn.classList.add("active-call");
      connectBtnLabel.textContent = "End Call Session";
      micBtn.disabled = false;
      silenceBtn.disabled = false;
    } else if (state === "connecting") {
      connectBtnLabel.textContent = "Connecting...";
    } else {
      connectBtn.classList.remove("active-call");
      connectBtnLabel.textContent = "Start Live Call Session";
      micBtn.disabled = true;
      silenceBtn.disabled = true;
    }
  }

  function setClassicStepper(activeStage, sttMs, llmMs, ttsMs, totalMs) {
    stepStt.setAttribute("data-active", activeStage === "stt" ? "true" : "false");
    stepLlm.setAttribute("data-active", activeStage === "llm" ? "true" : "false");
    stepTts.setAttribute("data-active", activeStage === "tts" ? "true" : "false");

    if (typeof sttMs === "number") stepSttTime.textContent = `${sttMs} ms`;
    if (typeof llmMs === "number") stepLlmTime.textContent = `${llmMs} ms`;
    if (typeof ttsMs === "number") stepTtsTime.textContent = `${ttsMs} ms`;
    if (typeof totalMs === "number") classicLastTtfa.textContent = `${totalMs} ms`;
  }

  function updateWaterfallAndScorecard(vadMs, sttMs, llmMs, ttsMs, classicTotalMs) {
    const scaleMax = Math.max(4200, classicTotalMs || 3600, (lastMeasuredLiveMs || 450) * 2);

    if (typeof lastMeasuredLiveMs === "number") {
      const livePct = Math.min(100, Math.max(4, (lastMeasuredLiveMs / scaleMax) * 100));
      wfBarLive.style.width = `${livePct}%`;
      wfLiveLabel.textContent = `${lastMeasuredLiveMs} ms`;
      tableLiveTtfa.textContent = `${lastMeasuredLiveMs} ms`;
    }

    if (typeof classicTotalMs === "number") {
      const vadPct = ((vadMs || 500) / scaleMax) * 100;
      const sttPct = ((sttMs || 0) / scaleMax) * 100;
      const llmPct = ((llmMs || 0) / scaleMax) * 100;
      const ttsPct = ((ttsMs || 0) / scaleMax) * 100;

      wfSegVad.style.width = `${vadPct}%`;
      wfSegStt.style.width = `${sttPct}%`;
      wfSegLlm.style.width = `${llmPct}%`;
      wfSegTts.style.width = `${ttsPct}%`;
      wfClassicLabel.textContent = `${classicTotalMs} ms`;
      tableClassicTtfa.textContent = `${classicTotalMs} ms`;
    }

    if (typeof lastMeasuredLiveMs === "number" && typeof lastMeasuredClassicMs === "number") {
      const ratio = (lastMeasuredClassicMs / Math.max(1, lastMeasuredLiveMs)).toFixed(1);
      const savedMs = lastMeasuredClassicMs - lastMeasuredLiveMs;
      speedupBadge.textContent = `Gemini 3.8 Live is ${ratio}x Faster (Saved ${savedMs} ms on this turn!)`;
      tableLatencyDelta.textContent = `${ratio}x Faster (-${savedMs} ms saved)`;
    }
  }

  function connectWebSocket(callbackOnOpen) {
    if (ws && isConnected) {
      if (callbackOnOpen) callbackOnOpen();
      return;
    }
    ensurePlaybackContext();
    updateConnectionUI("connecting", "Connecting to Gemini 3.8 Live...");

    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const mode = encodeURIComponent(modeSelect.value);
    const silenceSec = encodeURIComponent(silenceThresholdSelect.value || "5");
    const wsUrl = `${protocol}//${window.location.host}/ws/call?mode=${mode}&silence_sec=${silenceSec}`;

    ws = new WebSocket(wsUrl);

    ws.onopen = () => {
      if (callbackOnOpen) {
        pendingScenarioAfterConnect = callbackOnOpen;
      }
    };

    ws.onmessage = (event) => {
      let msg;
      try {
        msg = JSON.parse(event.data);
      } catch (_e) {
        return;
      }
      handleServerMessage(msg);
    };

    ws.onclose = () => {
      isConnected = false;
      stopMicCapture();
      updateConnectionUI("disconnected", "Session Ended");
      liveStateBadge.setAttribute("data-state", "idle");
      liveStateBadge.textContent = "Idle";
      classicStateBadge.setAttribute("data-state", "idle");
      classicStateBadge.textContent = "Idle";
    };
  }

  function handleServerMessage(msg) {
    switch (msg.type) {
      case "session_status": {
        if (msg.project) {
          projectBadge.textContent = `GCP: ${msg.project}`;
        }
        if (msg.status === "connected") {
          isConnected = true;
          updateConnectionUI("connected", "Gemini 3.8 Live Active");
          lastActivityTimestamp = performance.now();
          if (pendingScenarioAfterConnect) {
            const fn = pendingScenarioAfterConnect;
            pendingScenarioAfterConnect = null;
            fn();
          }
        } else if (msg.status === "error") {
          updateConnectionUI("disconnected", "Connection Error");
          appendChatBubble(
            liveTranscriptBox,
            "bubble-event",
            "System Alert",
            "Error",
            msg.message || "Could not connect to Vertex AI."
          );
        }
        break;
      }

      case "scenario_started": {
        activeLiveInputBubbleText = null;
        activeLiveOutputBubbleText = null;
        setClassicStepper("idle", null, null, null, null);
        stepSttTime.textContent = "...";
        stepLlmTime.textContent = "...";
        stepTtsTime.textContent = "...";
        break;
      }

      case "caller_playback": {
        stopAllPlaybackImmediately();
        activeLiveInputBubbleText = null;
        activeLiveOutputBubbleText = null;

        appendChatBubble(
          liveTranscriptBox,
          "bubble-customer",
          "Customer (Caller Audio Stream)",
          msg.emotion_tag || "16kHz PCM",
          msg.text
        );
        break;
      }

      case "caller_audio_chunk": {
        enqueuePcm24kBase64(msg.audio_b64, 0.9);
        break;
      }

      case "barge_in_demo_banner":
      case "live_interrupted": {
        stopAllPlaybackImmediately();
        bargeInCount = msg.barge_in_count || bargeInCount + 1;
        const recMs = msg.recovery_ms || 12;
        liveBargeMs.textContent = `${recMs} ms`;
        liveEventsCount.textContent = `${silenceCount} / ${bargeInCount}`;
        liveStateBadge.setAttribute("data-state", "interrupted");
        liveStateBadge.textContent = `Barge-In Halted (${recMs}ms)`;
        tableBargeImpact.textContent = `${bargeInCount} Barge-In(s) handled in ${recMs} ms`;

        appendChatBubble(
          liveTranscriptBox,
          "bubble-event",
          "Additional Talk / Barge-In Detected",
          `${recMs} ms stop`,
          msg.message || "Caller interrupted agent mid-turn; Gemini 3.8 Live flushed audio buffer and pivoted immediately."
        );
        activeLiveOutputBubbleText = null;
        break;
      }

      case "silence_timer_tick": {
        const elapsed = msg.elapsed_sec || 0;
        const thresh = msg.threshold_sec || 4.5;
        const pct = Math.min(100, (elapsed / thresh) * 100);
        silenceProgressFill.style.width = `${pct}%`;
        silenceTimerText.textContent = `${elapsed.toFixed(1)}s / ${thresh.toFixed(1)}s`;
        break;
      }

      case "silence_event": {
        silenceCount = msg.count || silenceCount + 1;
        liveEventsCount.textContent = `${silenceCount} / ${bargeInCount}`;
        tableSilenceImpact.textContent = `${silenceCount} Proactive Silence Check-In(s)`;
        silenceProgressFill.style.width = "100%";

        appendChatBubble(
          liveTranscriptBox,
          "bubble-silence",
          "Proactive Silence Monitor Triggered",
          "Gemini 3.8 Live",
          `${msg.reason} — Agent is proactively checking in with the customer.`
        );
        appendChatBubble(
          classicTranscriptBox,
          "bubble-silence",
          "Silence / Dead-Air Bottleneck",
          "Classic Pipeline",
          msg.classic_behavior || "Classic STT sits in dead air waiting for speech."
        );
        activeLiveOutputBubbleText = null;
        break;
      }

      case "live_input_transcript": {
        if (!activeLiveInputBubbleText && isMicActive) {
          const created = appendChatBubble(
            liveTranscriptBox,
            "bubble-customer",
            "Customer (Live Mic)",
            "Native Audio",
            msg.full_text || msg.text
          );
          activeLiveInputBubbleText = created.contentDiv;
        } else if (activeLiveInputBubbleText) {
          activeLiveInputBubbleText.textContent = msg.full_text || msg.text;
          liveTranscriptBox.scrollTop = liveTranscriptBox.scrollHeight;
        }
        break;
      }

      case "live_output_transcript": {
        liveStateBadge.setAttribute("data-state", "speaking");
        liveStateBadge.textContent = "Speaking Live";
        if (!activeLiveOutputBubbleText) {
          const badgeStr = lastMeasuredLiveMs ? `TTFA: ${lastMeasuredLiveMs} ms` : "Streaming";
          const created = appendChatBubble(
            liveTranscriptBox,
            "bubble-agent-live",
            "Clara (Gemini 3.8 Live Agent)",
            badgeStr,
            msg.full_text || msg.text
          );
          activeLiveOutputBubbleText = created.contentDiv;
          activeLiveOutputBadge = created.badgeSpan;
        } else {
          activeLiveOutputBubbleText.textContent = msg.full_text || msg.text;
          liveTranscriptBox.scrollTop = liveTranscriptBox.scrollHeight;
        }
        break;
      }

      case "live_audio": {
        liveStateBadge.setAttribute("data-state", "speaking");
        liveStateBadge.textContent = "Streaming 24kHz Audio";
        lastActivityTimestamp = performance.now();
        agentFinishedTurn = false;

        if (typeof msg.ttfa_ms === "number") {
          lastMeasuredLiveMs = msg.ttfa_ms;
          liveTtfaHistory.push(msg.ttfa_ms);
          const avg = Math.round(
            liveTtfaHistory.reduce((a, b) => a + b, 0) / liveTtfaHistory.length
          );
          liveLastTtfa.textContent = `${msg.ttfa_ms} ms`;
          liveAvgTtfa.textContent = `${avg} ms`;
          if (activeLiveOutputBadge) {
            activeLiveOutputBadge.textContent = `TTFA: ${msg.ttfa_ms} ms`;
          }
          updateWaterfallAndScorecard(500, 0, 0, 0, lastMeasuredClassicMs);
        }

        if (audioOutputSelect.value === "live" || audioOutputSelect.value === "sequential") {
          enqueuePcm24kBase64(msg.audio_b64, 1.0);
        }
        break;
      }

      case "live_turn_complete": {
        liveStateBadge.setAttribute("data-state", "idle");
        liveStateBadge.textContent = "Listening";
        activeLiveInputBubbleText = null;
        activeLiveOutputBubbleText = null;
        activeLiveOutputBadge = null;
        lastActivityTimestamp = performance.now();
        agentFinishedTurn = true;
        silenceTriggeredThisTurn = false;

        if (audioOutputSelect.value === "sequential" && deferredClassicAudioQueue.length > 0) {
          while (deferredClassicAudioQueue.length > 0) {
            enqueuePcm24kBase64(deferredClassicAudioQueue.shift(), 1.0);
          }
        }
        break;
      }

      case "classic_stage": {
        classicStateBadge.setAttribute("data-state", "processing");
        classicStateBadge.textContent = `Stage: ${String(msg.stage).toUpperCase()}`;
        setClassicStepper(msg.stage, msg.stt_ms, msg.llm_ms, msg.tts_ms, null);
        break;
      }

      case "classic_InputTranscript": {
        appendChatBubble(
          classicTranscriptBox,
          "bubble-customer",
          `Customer (Cloud STT: ${msg.stt_ms} ms)`,
          msg.lost_context || "Tone Stripped",
          msg.text
        );
        break;
      }

      case "classic_complete": {
        classicStateBadge.setAttribute("data-state", "idle");
        classicStateBadge.textContent = `Done (${msg.total_ms} ms)`;
        lastMeasuredClassicMs = msg.total_ms;
        classicTtfaHistory.push(msg.total_ms);

        setClassicStepper("done", msg.stt_ms, msg.llm_ms, msg.tts_ms, msg.total_ms);
        updateWaterfallAndScorecard(
          msg.vad_ms,
          msg.stt_ms,
          msg.llm_ms,
          msg.tts_ms,
          msg.total_ms
        );

        appendChatBubble(
          classicTranscriptBox,
          "bubble-agent-classic",
          "Classic Agent (STT -> Gemini -> TTS)",
          `Total TTFA: ${msg.total_ms} ms (STT ${msg.stt_ms} + LLM ${msg.llm_ms} + TTS ${msg.tts_ms})`,
          msg.transcript_out
        );
        break;
      }

      case "classic_audio_chunk": {
        if (audioOutputSelect.value === "classic") {
          enqueuePcm24kBase64(msg.audio_b64, 1.0);
        } else if (audioOutputSelect.value === "sequential") {
          if (liveStateBadge.getAttribute("data-state") === "speaking") {
            deferredClassicAudioQueue.push(msg.audio_b64);
          } else {
            enqueuePcm24kBase64(msg.audio_b64, 1.0);
          }
        }
        break;
      }
    }
  }

  // Microphone Capture (16kHz PCM)
  async function startMicCapture() {
    if (isMicActive) return;
    try {
      micStream = await navigator.mediaDevices.getUserMedia({
        audio: {
          channelCount: 1,
          sampleRate: 16000,
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
        },
      });
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      micAudioCtx = new AudioCtx({ sampleRate: 16000 });
      const source = micAudioCtx.createMediaStreamSource(micStream);
      micProcessor = micAudioCtx.createScriptProcessor(2048, 1, 1);

      micProcessor.onaudioprocess = (e) => {
        if (!isMicActive || !ws || !isConnected) return;
        const input = e.inputBuffer.getChannelData(0);
        const pcm16 = new Int16Array(input.length);
        let sumSq = 0;
        for (let i = 0; i < input.length; i++) {
          const s = Math.max(-1, Math.min(1, input[i]));
          sumSq += s * s;
          pcm16[i] = s < 0 ? s * 0x8000 : s * 0x7fff;
        }
        currentRms = Math.sqrt(sumSq / input.length);
        if (currentRms > 0.02) {
          lastActivityTimestamp = performance.now();
          silenceProgressFill.style.width = "0%";
        }

        const bytes = new Uint8Array(pcm16.buffer);
        let binary = "";
        for (let i = 0; i < bytes.byteLength; i++) {
          binary += String.fromCharCode(bytes[i]);
        }
        ws.send(
          JSON.stringify({
            type: "audio_chunk",
            data: window.btoa(binary),
          })
        );
      };

      source.connect(micProcessor);
      micProcessor.connect(micAudioCtx.destination);
      isMicActive = true;
      lastActivityTimestamp = performance.now();
      micBtn.classList.add("mic-live");
      micBtnLabel.textContent = "Mute Microphone (Live)";
      micStateLabel.textContent = "Mic Live (16kHz)";
    } catch (_err) {
      micStateLabel.textContent = "Mic Blocked";
    }
  }

  function stopMicCapture() {
    isMicActive = false;
    currentRms = 0;
    if (micProcessor) {
      try {
        micProcessor.disconnect();
      } catch (_e) {}
      micProcessor = null;
    }
    if (micAudioCtx) {
      try {
        micAudioCtx.close();
      } catch (_e) {}
      micAudioCtx = null;
    }
    if (micStream) {
      micStream.getTracks().forEach((t) => t.stop());
      micStream = null;
    }
    micBtn.classList.remove("mic-live");
    micBtnLabel.textContent = "Unmute Mic & Talk Live";
    micStateLabel.textContent = "Mic Idle";
  }

  // Waveform & Auto-Silence Monitor Loop
  const canvasCtx = waveformCanvas.getContext("2d");
  const waveBars = new Array(24).fill(3);

  function renderLoop() {
    const targetHeight = isMicActive
      ? Math.min(28, Math.max(3, currentRms * 260))
      : liveStateBadge.getAttribute("data-state") === "speaking"
      ? 10 + Math.random() * 14
      : 3;

    waveBars.shift();
    waveBars.push(targetHeight);

    canvasCtx.clearRect(0, 0, waveformCanvas.width, waveformCanvas.height);
    const barWidth = 6;
    const gap = 3;
    for (let i = 0; i < waveBars.length; i++) {
      const h = waveBars[i];
      const y = (waveformCanvas.height - h) / 2;
      canvasCtx.fillStyle = isMicActive ? "#ef4444" : "#10b981";
      canvasCtx.fillRect(i * (barWidth + gap), y, barWidth, h);
    }

    // Check Auto-Silence Threshold when mic is active and agent finished speaking
    const thresholdSec = parseFloat(silenceThresholdSelect.value || "0");
    if (
      isConnected &&
      isMicActive &&
      thresholdSec > 0 &&
      agentFinishedTurn &&
      !silenceTriggeredThisTurn
    ) {
      const elapsedSec = (performance.now() - lastActivityTimestamp) / 1000.0;
      const pct = Math.min(100, (elapsedSec / thresholdSec) * 100);
      silenceProgressFill.style.width = `${pct}%`;
      silenceTimerText.textContent = `${Math.min(elapsedSec, thresholdSec).toFixed(1)}s / ${thresholdSec.toFixed(1)}s`;

      if (elapsedSec >= thresholdSec) {
        silenceTriggeredThisTurn = true;
        ws.send(
          JSON.stringify({
            type: "trigger_silence",
            reason: `Customer silent on live mic for ${thresholdSec.toFixed(0)} seconds`,
          })
        );
      }
    }

    window.requestAnimationFrame(renderLoop);
  }
  window.requestAnimationFrame(renderLoop);

  // Event Listeners
  connectBtn.addEventListener("click", () => {
    if (isConnected && ws) {
      ws.close();
    } else {
      connectWebSocket();
    }
  });

  micBtn.addEventListener("click", () => {
    if (isMicActive) {
      stopMicCapture();
    } else {
      startMicCapture();
    }
  });

  silenceBtn.addEventListener("click", () => {
    if (!isConnected || !ws) return;
    ws.send(
      JSON.stringify({
        type: "trigger_silence",
        reason: "Caller paused on the line (Manual Silence Reaction Demo)",
      })
    );
  });

  document.querySelectorAll(".scenario-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      const scenarioId = btn.getAttribute("data-scenario");
      if (!scenarioId) return;
      const launch = () => {
        if (ws && isConnected) {
          ws.send(JSON.stringify({ type: "run_scenario", scenario_id: scenarioId }));
        }
      };
      if (!isConnected) {
        connectWebSocket(launch);
      } else {
        launch();
      }
    });
  });

  function sendCustomTextTurn() {
    const txt = (quickTextInput.value || "").trim();
    if (!txt) return;
    quickTextInput.value = "";
    const dispatch = () => {
      appendChatBubble(
        liveTranscriptBox,
        "bubble-customer",
        "Customer (Typed Prompt)",
        "Text -> Live",
        txt
      );
      ws.send(JSON.stringify({ type: "send_text_turn", text: txt }));
    };
    if (!isConnected) {
      connectWebSocket(dispatch);
    } else {
      dispatch();
    }
  }

  sendTextBtn.addEventListener("click", sendCustomTextTurn);
  quickTextInput.addEventListener("keydown", (e) => {
    if (e.key === "Enter") {
      e.preventDefault();
      sendCustomTextTurn();
    }
  });

  modeSelect.addEventListener("change", () => {
    if (ws && isConnected) {
      ws.send(
        JSON.stringify({
          type: "update_settings",
          mode: modeSelect.value,
        })
      );
    }
  });

  silenceThresholdSelect.addEventListener("change", () => {
    const val = parseFloat(silenceThresholdSelect.value || "5");
    if (val > 0) {
      silenceTimerText.textContent = `0.0s / ${val.toFixed(1)}s`;
    } else {
      silenceTimerText.textContent = "Manual Only";
    }
    if (ws && isConnected) {
      ws.send(
        JSON.stringify({
          type: "update_settings",
          silence_sec: val || 15,
        })
      );
    }
  });

  clearHistoryBtn.addEventListener("click", () => {
    liveTranscriptBox.replaceChildren();
    classicTranscriptBox.replaceChildren();
    liveTtfaHistory.length = 0;
    classicTtfaHistory.length = 0;
    lastMeasuredLiveMs = null;
    lastMeasuredClassicMs = null;
    silenceCount = 0;
    bargeInCount = 0;
    liveLastTtfa.textContent = "\u2014";
    liveAvgTtfa.textContent = "\u2014";
    classicLastTtfa.textContent = "\u2014";
    liveEventsCount.textContent = "0 / 0";
    wfBarLive.style.width = "0%";
    wfSegVad.style.width = "0%";
    wfSegStt.style.width = "0%";
    wfSegLlm.style.width = "0%";
    wfSegTts.style.width = "0%";
    wfLiveLabel.textContent = "\u2014 ms";
    wfClassicLabel.textContent = "\u2014 ms";
    speedupBadge.textContent = "Metrics reset — ready for next benchmark turn";
  });

  // Load configured global project ID from backend on startup
  fetch("/api/health")
    .then((res) => (res.ok ? res.json() : null))
    .then((data) => {
      if (data && data.resolved_gcp_project && projectBadge) {
        projectBadge.textContent = `GCP: ${data.resolved_gcp_project}`;
      }
    })
    .catch(() => {});
})();
