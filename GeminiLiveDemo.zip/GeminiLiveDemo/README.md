# Gemini 3.8 Live — Contact Center Benchmark & Live Demo

An interactive local web application built for demonstrating **Gemini 3.8 Live (`gemini-3.8-live`)** to Call Center / Contact Center leaders and comparing it side-by-side against a traditional **Google Cloud Speech-to-Text (`telephony`) &rarr; Gemini Flash &rarr; Google Cloud Text-to-Speech (`en-US-Journey-F`)** pipeline in GCP project `ccai-demo52788` (`ccai-demo-52788`).

## 1-Click Demo Scenarios Included

1. **Scenario 1 — Billing Problem (`billing_dispute`)**:
   - Customer calls frustrated about a duplicate `$89.99` charge on Support Case `#BILL-1042` and requests an immediate refund to their Visa ending in `**42`.
2. **Scenario 2 — Technical Problem (`tech_gemini_live` — Use `global` Region)**:
   - Customer asks how to work with **Gemini 3.8 Live** on Google Cloud Vertex AI and why their connection is failing. The Support Agent walks them through Case `#TECH-3801`: configuring `location="global"` in their Vertex AI client initialization and streaming 16kHz PCM audio via `client.aio.live.connect(model="gemini-3.8-live")`.
3. **Scenario 3 — General Talk & Strict Guardrails (`general_agent_check`)**:
   - Customer asks what the support agent can do and how it can help them, while probing restricted topics (comparing AWS/Azure, asking about politics/elections, and asking a historical date question). Demonstrates how the agent explains its support capabilities while strictly enforcing its guardrails.
4. **Scenario 4 — Additional Talk & Mid-Turn Barge-In (`additional_talk`)**:
   - Customer starts asking about their billing refund, then interrupts mid-sentence with additional talk about whether they need the `global` region for Gemini 3.8 Live.
5. **Scenario 5 — Caller Silence / Hold Reaction (`silence_reaction`)**:
   - Customer says *"Hold on while I open my Google Cloud console to check if my location is set to global..."* and stays silent for `4.5s`. Demonstrates Gemini 3.8 Live's proactive silence check-in vs. Classic STT dead air.

## Enforced Support Agent Guardrails

The support agent (`Clara`) is configured with strict system instructions:
- **Support Cases Only**: Only assists with active Google Cloud technical support and billing support cases.
- **No Politics**: Never discusses politics, elections, politicians, or government policy.
- **Google Cloud Only**: Never discusses, compares, or troubleshoots other cloud providers (such as AWS or Azure)—exclusively Google Cloud.
- **No General Facts or Dates Knowledge**: Never answers general knowledge, trivia, historical facts, or date questions outside active support cases.

## Running Locally

```bash
python3 app.py
```

Then open **http://127.0.0.1:8088** in your browser.
